import { test, expect } from '@playwright/test';

test.use({
  locale: 'ru-RU',
  timezoneId: 'Europe/Riga',
  viewport: {
    height: 720,
    width: 1280
  }
});

test('test', async ({ page }) => {
  await page.goto('BASE_URL/');
  await page.getByRole('textbox', { name: 'Username' }).fill('{server_username}');
  await page.getByRole('textbox', { name: 'Password' }).click();
  await page.getByRole('textbox', { name: 'Password' }).fill('{server_password}');
  await page.getByRole('textbox', { name: '2FA Code' }).fill('998567');
  await page.getByRole('button', { name: 'Log In' }).click();
  await page.getByRole('button', { name: 'Tools' }).click();
  await page.getByRole('link', { name: 'Actions' }).click();
  await page.getByRole('combobox').click();
  await page.getByRole('option', { name: 'Manual deposit', exact: true }).click();
  await page.locator('#mui-component-select-currency').click();
  await page.getByRole('option', { name: 'Arbitrum Ethereum', exact: true }).click();
  await page.getByLabel('', { exact: true }).click();
  await page.getByRole('option', { name: 'MaxMerchStage (Max)', exact: true }).click();
  await page.getByRole('textbox', { name: 'USD amount' }).click();
  await page.getByRole('textbox', { name: 'USD amount' }).fill('5');
  await page.locator('input[name="twoFactorAuthToken"]').click();
  await page.locator('input[name="twoFactorAuthToken"]').fill('{server_2faotp}');
  await page.getByRole('button', { name: 'Create deposit' }).click();
  await expect(page.getByRole('heading', { name: 'Deposit info' })).toBeVisible();
});