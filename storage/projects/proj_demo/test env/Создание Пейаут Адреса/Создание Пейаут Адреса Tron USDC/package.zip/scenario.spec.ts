import { test, expect } from '@playwright/test';

test.use({
  locale: 'ru-RU',
  timezoneId: 'Europe/Riga',
  viewport: {
    height: 720,
    width: 1280
  }
});

test('test', async ({ page }) => {
  await page.goto('BASE_URL/');
  await page.getByRole('textbox', { name: 'Username' }).click();
  await page.getByRole('textbox', { name: 'Username' }).fill('{server_username}');
  await page.getByRole('textbox', { name: 'Password' }).click();
  await page.getByRole('textbox', { name: 'Password' }).fill('{server_password}');
  await page.getByRole('textbox', { name: '2FA Code' }).click();
  await page.getByRole('textbox', { name: '2FA Code' }).fill('{server_2faotp}');
  await page.getByRole('button', { name: 'Log In' }).click();
  await page.getByRole('button', { name: 'Tools' }).click();
  await page.getByRole('link', { name: 'Wallets' }).click();
  await page.getByRole('button', { name: 'New Wallet' }).click();
  await page.getByRole('radio', { name: 'Payout W' }).check();
  await page.getByRole('textbox', { name: 'Nickname (Optional)' }).click();
  await page.getByRole('textbox', { name: 'Nickname (Optional)' }).fill('{{INPUT:additional_name}}');
  await page.locator('#mui-component-select-users').click();
  await page.getByRole('option', { name: '{server_merchant}' }).click();
  await page.mouse.click(20, 20);
  await page.getByLabel('', { exact: true }).click();
  await page.getByRole('option', { name: 'Tron USDC', exact: true }).click();
  await page.getByRole('radio', { name: 'MPC' }).check();
  await page.getByRole('button', { name: 'Generate' }).click();
  await page.getByText('Generation finished').click();
  await page.getByRole('button', { name: 'Close' }).click();
  await page.locator('input[name="twoFactorAuthToken"]').click();
  await page.locator('input[name="twoFactorAuthToken"]').fill('{server_2faotp}');
  await page.getByRole('button', { name: 'Submit' }).click();
});