import { test, expect } from '@playwright/test';

test('Example Domain smoke', async ({ page }) => {
  await page.goto('BASE_URL/');
  await expect(page).toHaveURL(/example\.com/);
  await expect(page.getByRole('heading', { name: 'Example Domain' })).toBeVisible();
});